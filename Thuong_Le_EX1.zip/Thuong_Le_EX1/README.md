# Software Atelier Project 1
This is the first project of the SA3 class.