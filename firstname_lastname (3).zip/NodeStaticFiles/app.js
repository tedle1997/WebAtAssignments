$(function(){
	$("#OEV-general-info").tablesorter({sortList:[[0,0]]});
})