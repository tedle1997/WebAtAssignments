'use strict';

var path = require('path')
module.exports={
  baseURL : 'http://127.0.0.1:3000',
  projectRoot : path.resolve(__dirname, '../..')
}