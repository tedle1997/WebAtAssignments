//  Enter your initialization code here

function init() {

    // Create canvas app
    const app = new App({ canvas: 'canvas', 
    	                  buttons: { clear: 'clear-btn', camera: 'camera-btn', undo: 'undo-btn' },
                          brushToolbar: 'brush-toolbar' 
    	                });



    }